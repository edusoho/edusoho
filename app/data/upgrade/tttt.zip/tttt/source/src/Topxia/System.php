<?php

namespace Topxia;


class System 
{
	CONST VERSION = '2.0.0';
	CONST RELEASE_NOTES = "http://www.edusoho.com/intro/13";
}
