<?php

namespace Custom\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CustomAdminBundle extends Bundle
{
}
