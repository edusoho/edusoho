<?php

namespace Custom\Service\User;

interface UserService
{
	
	public function updateUser($id,$field);
   
}