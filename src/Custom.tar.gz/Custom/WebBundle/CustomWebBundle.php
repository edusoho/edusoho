<?php

namespace Custom\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CustomWebBundle extends Bundle
{
}
